import os, glob

def replace_dashes(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Characters to replace
    dashes = [
        '\u2013', # En Dash
        '\u2014', # Em Dash
        '\u2212', # Minus Sign
        '\u2015'  # Horizontal Bar
    ]
    
    new_content = content
    for dash in dashes:
        new_content = new_content.replace(dash, '-')
        
    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f'Updated dashes in {os.path.basename(filepath)}')

# Glob all html and css files
search_paths = [
    'c:/Users/Lenovo/Downloads/akf_website_fixed/akf_fix/*.html',
    'c:/Users/Lenovo/Downloads/akf_website_fixed/akf_fix/*.css',
    'c:/Users/Lenovo/Downloads/akf_website_fixed/akf_fix/templates/*.html'
]

for spath in search_paths:
    for file in glob.glob(spath):
        replace_dashes(file)

print('Dashes successfully replaced.')
