import os
import glob

directory = 'c:/Users/Lenovo/Downloads/akf_website_fixed/akf_fix'
files = glob.glob(os.path.join(directory, '*.html'))

for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if '<li><a href="programs.html"' in content and 'ak_care_labs.html' not in content:
        print(f'Updating {os.path.basename(file)}')
        old_str1 = '<li><a href="programs.html">Programs</a></li>'
        new_str1 = '<li><a href="programs.html">Programs</a></li>\n        <li><a href="ak_care_labs.html">AK Care Labs</a></li>'
        
        old_str2 = '<li><a href="programs.html" style="color:var(--teal)">Programs</a></li>'
        new_str2 = '<li><a href="programs.html" style="color:var(--teal)">Programs</a></li>\n        <li><a href="ak_care_labs.html">AK Care Labs</a></li>'
        
        if old_str1 in content:
            content = content.replace(old_str1, new_str1)
        elif old_str2 in content:
            content = content.replace(old_str2, new_str2)
            
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
print('Done!')
