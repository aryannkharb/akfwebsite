import glob, os

files = glob.glob('c:/Users/Lenovo/Downloads/akf_website_fixed/akf_fix/*.html')
for file in files:
    with open(file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Case 1 (with style)
    target1 = '<p style="color:var(--muted); font-size:.8rem">Proudly created by <a href="https://www.linkedin.com/in/punit-lohan-8513b5222/" target="_blank" style="color:var(--teal); text-decoration:none;">Punit Lohan</a></p>'
    replacement1 = '<p style="color:var(--muted); font-size:.8rem">Developed with AKF Love and Care</p>'
    
    # Case 2 (without style)
    target2 = '<p>Proudly created by <a href="https://www.linkedin.com/in/punit-lohan-8513b5222/" target="_blank" style="color:var(--teal); text-decoration:none;">Punit Lohan</a></p>'
    replacement2 = '<p>Developed with AKF Love and Care</p>'
    
    new_content = content.replace(target1, replacement1).replace(target2, replacement2)
    
    if new_content != content:
        with open(file, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f'Updated {os.path.basename(file)}')
print('Done!')
